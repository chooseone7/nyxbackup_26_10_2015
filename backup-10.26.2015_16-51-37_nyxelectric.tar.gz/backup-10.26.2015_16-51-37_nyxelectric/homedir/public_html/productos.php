	<section id="contenido">
				<section id="principal-productos">
					<article id="galeria-inicio">		
				</article>
						<div id="galeria-nyx-productos">

					<div id="lista-productos-recomendables" style="background:none;">	
						<div class="mostrar-producto">
						<?php include("sql/cproductos.php");?>
						</div>
					
					<!-- <p class="contenido-producto"></p> -->
						</div>
						<aside id="aside-productos">
					      <div class="envoltorio-productos">
                            <div id="lateral-novedades-productos" style="text-align:center;">
                               <p>
					<b>Contactanos:</b><br/>
					Av.   Ovidio Barbery,8888 esq. Francisco Amil<br/>
					#492 Z/b Mc. Donald<br/>
					 Uv. 0036 Mza. 0021<BR/>
					Santa Cruz - Bolivia<br/>
					Oficina 3305197<br/>
					Celular 708-51402
						</p>
                            </div>
							<div id="lateral-novedades-novedades">
								<p> novedades novedades</p>
								
							</div><img src="img/certificate2.png" width="260" height="36" alt="certificados" /> 
						</div>
						</aside>
					</div>
				</section>
			</section>