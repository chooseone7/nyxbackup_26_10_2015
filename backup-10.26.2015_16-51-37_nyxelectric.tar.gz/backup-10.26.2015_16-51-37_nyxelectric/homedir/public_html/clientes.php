<!-- --><br />
<?php $footer_opcion=true;?>
	<section id="contenido">
				<section id="principal">
					<article id="galeria-inicio">		
			<div class="flexslider">
						<ul class="slides">
                        
							<li>
								<a href="#">
								<img src="img/01.jpg" alt="grande"/>
                                </a>
                                <p> google.com
								</p>
							</li>
                            <li>
								<a href="#">
								<img src="img/02.jpg" alt="imagen2"/></a>
								<p class="flex-caption">
								  google.com</p>
							</li>
							
						</ul>
					</div>

					</article>
					
						<div id="galeria-nyx">
						<div id="sector-categoria-cliente">
							asdfasdfasfd
						</div>
					<div id="lista-productos-recomendables">
						<p class="contenido-producto">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<p class="contenido-producto">
						Ã­tulo del destacado Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
						</p>
						<p class="contenido-producto">
						Ã­tulo del destacado Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
						</p>
						<p class="contenido-producto">
						Ã­tulo del destacado Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
						</p>
						
					</div>
				</div>
				
				
				
			</section>
		
				</section>
		