<!-- -->
<?php $footer_opcion=true;?>
	<section id="contenido">
				<section id="principal">
						<div id="galeria-nyx-contactanos" style="background:none; border:none;margin-right:0em;text-align:left; display:inline;">
							<div id="lista-productos-recomendables-novedades">
							<p class="contenido-producto">
                            Esto esta arriba del parrafo que esta arriba de la imagen Esta imagen esta despues
                              Esto esta arriba del parrafo q Esto esta arriba del parrafo q Esto esta arriba del parrafo q asdf asdf asdf </p> 
								<br />
								<h3 class="primer-encabezado-novedades">Novedad 1</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/c.png"  alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes </p>		
								<h3>Novedad 2</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/c.png"  alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes</p> 							<h3>Novedad 3</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/c.png"  alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes</p> 	
						</div>
<aside id="aside-novedades"><!--style="display:inline-block; margin-right:20px;max-width:20%;" -->
                    
                    
						<!--<section class="widget">
							<h3>Certificaciones Recientes</h3>
							<ul class="lista-articulos-widget">
								<li class="lista-articulos-recientes"><a href="#">Certificado 1</a></li>
								<li class="lista-articulos-recientes"><a href="#">Certificado 2</a></li>
							</ul>
                          <p>prueba</p>

						</section> -->
					
                         <div class="envoltorio-novedades">
                            <div id="lateral-novedades-contactanos">
                               <p>
					<b>Contactanos:</b><br/>
					Av.   Ovidio Barbery, esq. Francisco Amil<br/>
					#492 Z/b Mc. Donald<br/>
					 Uv. 0036 Mza. 0021<BR/>
					Santa Cruz - Bolivia<br/>
					Oficina 3305197<br/>
					Celular 768-91711 
						</p>
                            </div>
							<div id="lateral-novedades-novedades">
								<p> novedades novedades</p>
								
							</div><img src="img/certificate2.png" width="260" height="36" alt="certificados" /> 
						</div>

					</aside>
					</div>
		</section>
		</section>
		