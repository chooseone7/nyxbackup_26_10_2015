	<section id="contenido">
				<section id="principal-productos">
					<article id="galeria-inicio">		
				</article>
						<div id="galeria-nyx-productos">

					<div id="lista-productos-recomendables" >	
						<p class="contenido-producto">
                            Esto esta arriba del parrafo que esta arriba de la imagen Esta imagen esta despues
                              Esto esta arriba del parrafo q Esto esta arriba del parrafo q Esto esta arriba del parrafo q asdf asdf asdf </p> 
								
								<h3>Novedad 1</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/imgproductos/interiores/7W.JPG"  width="200" alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes </p>		
								<h3>Novedad 2</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/imgproductos/interiores/7W.JPG" width="200" alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes</p>
								<h3>Novedad 3</h3>	
							 <p class="contenido-producto">Este parrafo esta antes de la imagen ok ok 
							   <img class="imagen-centrado" style="" src="img/imgproductos/interiores/7W.JPG"  width="200" alt="1" />
							   Esta imagen esta despues de la imagen y antes de que termine el parrafo
								Esta imagen esta despues de la imagen y antes de que termine el parrafo
								de la imagen y antes de que aa de la imagen y antes de que aa de la imagen y antes</p> 	
								
					
					<!--<div class="mostrar-producto">
						<?php //include("sql/cproductos.php");?>
						</div> <p class="contenido-producto"></p> -->
						</div>
						<aside id="aside-productos">
					      <div class="envoltorio-productos">
                            <div id="lateral-novedades-productos" style="text-align:center;">
                               <p>
					<b>Contactanos:</b><br/>
					Av.   Ovidio Barbery,8888 esq. Francisco Amilss<br/>
					#492 Z/b Mc. Donald<br/>
					 Uv. 0036 Mza. 0021<BR/>
					Santa Cruz - Bolivia<br/>
					Oficina 3305197<br/>
					Celular 708-51402
						</p>
                            </div>
							<div id="lateral-novedades-novedades">
								<p> novedades novedades</p>
								
							</div><img src="img/certificate2.png" width="260" height="36" alt="certificados" /> 
						</div>
						</aside>
					</div>
				</section>
			</section>