-- cPanel mysql backup
GRANT USAGE ON *.* TO 'nyxelect_marco'@'localhost' IDENTIFIED BY PASSWORD '*6813359E00C37469F8A1798DE0E968C7CCC12EC1';
GRANT ALL PRIVILEGES ON `nyxelect\_bd`.* TO 'nyxelect_marco'@'localhost';
GRANT USAGE ON *.* TO 'nyxelectric'@'localhost' IDENTIFIED BY PASSWORD '*3B1B4F51D4B5B8E0C3BA4DD9EB7E1EC4A92C2178';
GRANT ALL PRIVILEGES ON `nyxelect\_bd`.* TO 'nyxelectric'@'localhost';
